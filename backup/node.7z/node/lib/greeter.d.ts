export declare class Greeter {
    private greeting;
    constructor(message: string);
    greet(): string;
}
